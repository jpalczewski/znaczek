# znaczek
Simple app that helps in managing labels
